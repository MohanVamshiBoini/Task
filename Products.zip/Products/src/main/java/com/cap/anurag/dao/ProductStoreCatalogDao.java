package com.cap.anurag.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.anurag.entities.ProductStoreCatalog;

public interface ProductStoreCatalogDao extends JpaRepository<ProductStoreCatalog,Integer>{

}
