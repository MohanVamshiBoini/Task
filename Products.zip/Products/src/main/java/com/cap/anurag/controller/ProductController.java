package com.cap.anurag.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.anurag.entities.Product;
import com.cap.anurag.entities.ProductCategoryMember;
import com.cap.anurag.entities.ProductStoreCatalog;
import com.cap.anurag.service.ProductCategoryMemberService;
import com.cap.anurag.service.ProductService;
import com.cap.anurag.service.ProductStoreCatalogService;
@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController {
	@Autowired
	ProductService service;
	@Autowired
	ProductCategoryMemberService pservice;
	@Autowired
	ProductStoreCatalogService pcservice;

	@PostMapping("/create")
	public ResponseEntity<Boolean> create(@RequestBody Product product){ 
		System.out.println(product);
		//product = service.create(product,productCategoryMember);
		product = service.create(product);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}
	@PostMapping("/createProductCategoryMember")
	public ResponseEntity<Boolean> createProductCategoryMember(@RequestBody ProductCategoryMember productCategoryMember){ 
		System.out.println(productCategoryMember);
		productCategoryMember = pservice.create(productCategoryMember);
		//product = service.create(product,productCategoryMember);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}
	@PostMapping("/createProductStoreCatalog")
	public ResponseEntity<Boolean> createProductStoreCatalog(@RequestBody ProductStoreCatalog productStoreCatalog){ 
		System.out.println(productStoreCatalog);
		productStoreCatalog = pcservice.create(productStoreCatalog);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}

	@PutMapping("/update")
	public ResponseEntity<Boolean> update(@RequestBody Product product) {
		//product.setProductId(product.getProductId());
		product = service.update(product);
		System.out.println(product);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}
	@PutMapping("/updateProductCategoryMember")
	public ResponseEntity<Boolean> updateProductCategoryMember(@RequestBody ProductCategoryMember productCategoryMember) {
		//product.setProductId(product.getProductId());
		productCategoryMember = pservice.update(productCategoryMember);
		System.out.println(productCategoryMember);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}
	@PutMapping("/updateProductStoreCatalog")
	public ResponseEntity<Boolean> updateProductStoreCatalog(@RequestBody ProductStoreCatalog productStoreCatalog){ 
		System.out.println(productStoreCatalog);
		productStoreCatalog = pcservice.update(productStoreCatalog);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
		System.out.println("response entity=" + responseEntity);
		return responseEntity;
	}

	@DeleteMapping("/deleteProduct/{productId}")
	public String deleteProduct(@PathVariable("productId") Integer productId) {
		service.delete(productId);
		return "Deleted";
	}
	@DeleteMapping("/deleteProductCategoryMember/{productId}")
	public String deleteProductCategoryMember(@PathVariable("productId") Integer productId) {
		pservice.delete(productId);
		return "Deleted";
	}
	@DeleteMapping("/deleteProductStoreCatalog/{productCatalogId}")
	public String deleteProductStoreCatalog(@PathVariable("productCatalogId") Integer productCatalogId) {
		pcservice.delete(productCatalogId);
		return "Deleted";
	}

	@GetMapping("/findProduct/{productId}")
	public Optional<Product> findProduct(@PathVariable("productId") Integer productId) {
		return service.findProduct(productId);
	}
	@GetMapping("/findProductCategoryMember/{productId}")
	public Optional<ProductCategoryMember> findProductCategoryMember(@PathVariable("productId") Integer productId) {
		return pservice.findProductCategoryMember(productId);
	}
	@GetMapping("/findProductStoreCatalog/{productCatalogId}")
	public Optional<ProductStoreCatalog> findProductStoreCatalog(@PathVariable("productCatalogId") Integer productCatalogId) {
		return pcservice.findProductStoreCatalog(productCatalogId);
	}
}
