package com.cap.anurag.service;

import java.util.Optional;

import com.cap.anurag.entities.Product;

public interface ProductService {

	Product create(Product product);

	void delete(Integer productId);

	Optional<Product> findProduct(Integer productId);

	Product update(Product product);

}
