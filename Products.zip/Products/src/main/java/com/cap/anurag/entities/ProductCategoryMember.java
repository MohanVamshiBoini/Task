package com.cap.anurag.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "ProductCategoryMember")
public class ProductCategoryMember implements Serializable {
	private int productCategoryId;
	@Id
	@GeneratedValue
	private Integer productId;
	private Date fromDate;
	private Date thruDate;
	private String comments;
	private int sequenceNum;
	private int quantity;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="product_productId")
	private Product product;
	public ProductCategoryMember() {
		
	}
	public ProductCategoryMember(int productCategoryId,Integer productId, Date fromDate, Date thruDate, String comments,
			int sequenceNum, int quantity, Product product) {
		super();
		this.productCategoryId = productCategoryId;
		this.productId=productId;
		this.fromDate = fromDate;
		this.thruDate = thruDate;
		this.comments = comments;
		this.sequenceNum = sequenceNum;
		this.quantity = quantity;
		this.product = product;
	}
	public int getProductCategoryId() {
		return productCategoryId;
	}
	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getThruDate() {
		return thruDate;
	}
	public void setThruDate(Date thruDate) {
		this.thruDate = thruDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getSequenceNum() {
		return sequenceNum;
	}
	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "ProductCategoryMember [productCategoryId=" + productCategoryId + ", productId=" + productId
				+ ", fromDate=" + fromDate + ", thruDate=" + thruDate + ", comments=" + comments + ", sequenceNum="
				+ sequenceNum + ", quantity=" + quantity + ", product=" + product + "]";
	}
}
