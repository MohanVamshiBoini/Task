package com.cap.anurag.service;

import java.util.Optional;

import com.cap.anurag.entities.ProductStoreCatalog;

public interface ProductStoreCatalogService {

	ProductStoreCatalog create(ProductStoreCatalog productStoreCatalog);

	ProductStoreCatalog update(ProductStoreCatalog productStoreCatalog);

	void delete(Integer productCatalogId);

	Optional<ProductStoreCatalog> findProductStoreCatalog(Integer productCatalogId);


}
